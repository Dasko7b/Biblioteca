
#include "biblioteca_dinamica.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define INICIAL 10

void inicializarBiblioteca(Biblioteca* b) {
    b->livros = (Livro*) malloc(INICIAL * sizeof(Livro));
    b->capacidade = INICIAL;
    b->totalLivros = 0;
}

void redimensionarBiblioteca(Biblioteca* b, int novaCapacidade) {
    b->livros = (Livro*) realloc(b->livros, novaCapacidade * sizeof(Livro));
    b->capacidade = novaCapacidade;
}

int cadastrarLivro(Biblioteca* b, char* titulo, char* autor, int ano, char* isbn) {
    for (int i = 0; i < b->totalLivros; i++) {
        if (strcmp(b->livros[i].isbn, isbn) == 0) {
            return 0;
        }
    }

    if (b->totalLivros == b->capacidade) {
        redimensionarBiblioteca(b, b->capacidade * 2);
    }

    Livro novo;
    strcpy(novo.titulo, titulo);
    strcpy(novo.autor, autor);
    novo.ano = ano;
    strcpy(novo.isbn, isbn);
    novo.status = DISPONIVEL;
    strcpy(novo.usuario, "");
    strcpy(novo.dataEmprestimo, "");

    b->livros[b->totalLivros] = novo;
    b->totalLivros++;

    return 1;
}

void listarTodosLivros(Biblioteca* b) {
    for (int i = 0; i < b->totalLivros; i++) {
        Livro l = b->livros[i];
        printf("Titulo: %s\nAutor: %s\nAno: %d\nISBN: %s\nStatus: %s\n",
            l.titulo, l.autor, l.ano, l.isbn, l.status == DISPONIVEL ? "Disponivel" : "Emprestado");

        if (l.status == EMPRESTADO) {
            printf("Emprestado para: %s em %s\n", l.usuario, l.dataEmprestimo);
        }
        printf("-----------------------------\n");
    }
}

int emprestarLivro(Biblioteca* b, char* isbn, char* usuario, char* data) {
    for (int i = 0; i < b->totalLivros; i++) {
        if (strcmp(b->livros[i].isbn, isbn) == 0) {
            if (b->livros[i].status == DISPONIVEL) {
                b->livros[i].status = EMPRESTADO;
                strcpy(b->livros[i].usuario, usuario);
                strcpy(b->livros[i].dataEmprestimo, data);
                return 1;
            } else {
                return 0;
            }
        }
    }
    return 0;
}

int devolverLivro(Biblioteca* b, char* isbn) {
    for (int i = 0; i < b->totalLivros; i++) {
        if (strcmp(b->livros[i].isbn, isbn) == 0) {
            if (b->livros[i].status == EMPRESTADO) {
                b->livros[i].status = DISPONIVEL;
                strcpy(b->livros[i].usuario, "");
                strcpy(b->livros[i].dataEmprestimo, "");
                return 1;
            } else {
                return 0;
            }
        }
    }
    return 0;
}

Livro* consultarLivroPorISBN(Biblioteca* b, char* isbn) {
    for (int i = 0; i < b->totalLivros; i++) {
        if (strcmp(b->livros[i].isbn, isbn) == 0) {
            return &b->livros[i];
        }
    }
    return NULL;
}

void destruirBiblioteca(Biblioteca* b) {
    free(b->livros);
    b->livros = NULL;
    b->capacidade = 0;
    b->totalLivros = 0;
}
